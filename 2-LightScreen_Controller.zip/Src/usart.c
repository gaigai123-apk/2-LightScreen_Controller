/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
#include <string.h>
#include "gpio.h"

// 简化的接收缓冲区
uint8_t uart_rx_byte = 0;
uint8_t command_buffer[10] = {0};
uint8_t cmd_index = 0;
uint8_t command_complete = 0;

/**
  * @brief 串口接收中断回调 - 单字节接收
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1) {
    // 立即回显接收到的字节（用于调试）
    HAL_UART_Transmit(&huart1, &uart_rx_byte, 1, 10);
    
    // 检查结束符
    if (uart_rx_byte == '\r' || uart_rx_byte == '\n') {
      command_complete = 1;
    } else {
      // 存储到命令缓冲区
      if (cmd_index < 9) {
        command_buffer[cmd_index++] = uart_rx_byte;
      }
    }
    
    // 重新启动单字节接收
    HAL_UART_Receive_IT(&huart1, &uart_rx_byte, 1);
  }
}

/**
  * @brief 处理命令 - 极简版本
  */
void Process_Command(void)
{
  if (command_complete) {
    // 添加终止符
    command_buffer[cmd_index] = '\0';
    
    // 发送调试信息
    HAL_UART_Transmit(&huart1, (uint8_t*)"\r\nCMD:", 6, 100);
    HAL_UART_Transmit(&huart1, command_buffer, cmd_index, 100);
    HAL_UART_Transmit(&huart1, (uint8_t*)"\r\n", 2, 100);
    
    // 极简命令比较
    if (cmd_index == 2 && command_buffer[0] == 'O' && command_buffer[1] == 'N') {
      LED_On();
      HAL_UART_Transmit(&huart1, (uint8_t*)"ACTION:LED_ON\r\n", 15, 100);
    } 
    else if (cmd_index == 3 && command_buffer[0] == 'O' && command_buffer[1] == 'F' && command_buffer[2] == 'F') {
      LED_Off();
      HAL_UART_Transmit(&huart1, (uint8_t*)"ACTION:LED_OFF\r\n", 16, 100);
    }
    else {
      HAL_UART_Transmit(&huart1, (uint8_t*)"ACTION:UNKNOWN\r\n", 16, 100);
    }
    
    // 重置命令状态
    cmd_index = 0;
    memset(command_buffer, 0, 10);
    command_complete = 0;
  }
}
/* USER CODE END 0 */

UART_HandleTypeDef huart1;

/* USART1 init function */

void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;  // 从115200降到9600，提高稳定性
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */
    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();
  
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration    
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* USART1 interrupt Init */
	// 降低串口中断优先级，确保不影响系统延时
	HAL_NVIC_SetPriority(USART1_IRQn, 2, 0);  // 改为优先级2
	HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();
  
    /**USART1 GPIO Configuration    
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* USART1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */

/**
  * @brief 启动串口接收
  * @retval None
  */
/* USER CODE BEGIN 1 */
void USART1_StartReceive(void)
{
  // 启动单字节接收
  HAL_UART_Receive_IT(&huart1, &uart_rx_byte, 1);
}
/* USER CODE END 1 */
/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
