## OLED 集成说明（1-Serial_LED_Controller）

### 硬件连接
- OLED 接口：4针 I2C（SCL、SDA、VCC、GND）
- 默认引脚：
  - SCL -> PB8（开漏上拉）
  - SDA -> PB9（开漏上拉）
  - VCC -> 3.3V
  - GND -> GND

如需修改引脚，请同步更改 `Src/OLED.c` 中 `GPIOB, GPIO_PIN_8/9` 的定义与 `MX_GPIO_Init` 不冲突即可。

### 软件集成
已添加文件：
- `Inc/OLED.h`、`Inc/OLED_Data.h`
- `Src/OLED.c`（HAL 适配的软件 I2C 驱动）
- `Src/OLED_Data.c`（字库与图像数据，示例为精简版，可替换为完整数据）

工程文件：
- 已将 `OLED.c`、`OLED_Data.c` 加入 `MDK-ARM/5.uvprojx` 的 Application/User 分组

### 使用方法
在 `main.c` 中：
1. 头文件包含：`#include "OLED.h"`
2. 初始化后显示：
   - 在 `USART1_StartReceive();` 后增加：
     - `OLED_Init();`
     - `OLED_ShowString(0, 0, "LED:", OLED_6X8);`
     - `OLED_ShowString(30, 0, LED_IsOn() == GPIO_PIN_SET ? "ON " : "OFF", OLED_6X8);`
     - `OLED_Update();`
3. 实时刷新：
   - 在 `while(1)` 中根据 LED 状态变化调用：
     - `OLED_ShowString(30, 0, cur == GPIO_PIN_SET ? "ON " : "OFF", OLED_6X8);`
     - `OLED_UpdateArea(30, 0, 18, 8); // 3*6 像素宽的区域`

### 注意事项
- OLED 初始化使用软件 I2C 时序，若 MCU 频率较高可在 `OLED_W_SCL/SDA` 附近增加微小延时。
- 默认 I2C 从地址为 `0x78`（写）。
- 若使用 1.3 寸 SH1106 屏，请在 `OLED_SetCursor` 中启用 `X += 2` 的注释以对齐列。
- 若显示中文，请在 `Src/OLED_Data.c` 中补充对应汉字到 `OLED_CF16x16`。

### 构建
- 直接用 Keil 打开 `MDK-ARM/5.uvprojx` 构建下载即可。


